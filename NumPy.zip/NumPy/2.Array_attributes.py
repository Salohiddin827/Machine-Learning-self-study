import numpy as np
a_mul = np.array([[[1,2,3, 1],
                 [4,5,6, 1],
                 [7,8,9 ,1 ]],
                 [[1,1,1,1],
                  [1,1,1,1], 
                  [1,1,1,1]]])
print(a_mul.shape)
print(a_mul.ndim)
print(a_mul.shape)
print(a_mul.dtype)
print